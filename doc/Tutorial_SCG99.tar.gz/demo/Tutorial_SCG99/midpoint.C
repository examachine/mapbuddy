// examples/Tutorial_SCG99/midpoint.C
// ----------------------------------
#include "tutorial.h"
#include <CGAL/Point_2.h>
#include <iostream>

using CGAL::ORIGIN;

int main() {
    Point  p(  0.0, 0.0);
    Point  q(  3.0, 2.0);
    // Point m = (p+q)/2.0;
    Point m = ORIGIN + ((p - ORIGIN) + (q - ORIGIN)) / 2.0;
    std::cout << "m = (" << m.x() << ", " << m.y() << ")\n";
    return 0;
}
