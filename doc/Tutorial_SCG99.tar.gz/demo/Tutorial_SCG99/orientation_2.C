// examples/Tutorial_SCG99/orientation_2.C
// ---------------------------------------
#include "tutorial.h"
#include <CGAL/Point_2.h>
#include <CGAL/predicates_on_points_2.h>
#include <iostream>

int main() {
    Point p( 10/10,  0);
    Point q( 13/10, 17/10);
    Point r( 22/10, 68/10);
    switch ( CGAL::orientation( p, q, r)) {
	case CGAL::LEFTTURN:   std::cout << "Left turn.\n";  break;
	case CGAL::RIGHTTURN:  std::cout << "Right turn.\n"; break;
	case CGAL::COLLINEAR:  std::cout << "Collinear.\n";  break;
    }
    return 0;
}
