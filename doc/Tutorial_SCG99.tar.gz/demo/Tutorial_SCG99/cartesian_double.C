// examples/Tutorial_SCG99/cartesian_double.C
// ------------------------------------------
#include <CGAL/Cartesian.h>
#include <CGAL/Point_2.h>


typedef CGAL::Cartesian<double>         Rep;
typedef CGAL::Point_2<Rep>              Point;

int main() {
    Point  p( 0.1, 0.2);
    return 0;
}
