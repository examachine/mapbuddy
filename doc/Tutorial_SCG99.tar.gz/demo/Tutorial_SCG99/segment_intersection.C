// examples/Tutorial_SCG99/segment_intersection.h
// ----------------------------------------------
#include "tutorial.h"
#include <CGAL/intersections.h>

int main() {
    Segment s( Point(1,1), Point(1,5));
    Segment t( Point(1,3), Point(1,8));
    if ( CGAL::do_intersect( s, t)) {
	CGAL::Object result = CGAL::intersection( s, t);
	Point   pt;
	Segment seg;
	if (CGAL::assign( pt, result))
	    std::cout << "intsct. point = " << pt << std::endl;
	else if (CGAL::assign( seg, result))
	    std::cout << "intsct. segment = " << seg << std::endl;
    } else
	std::cout << "no intersection" << std::endl;
    return 0;
}
