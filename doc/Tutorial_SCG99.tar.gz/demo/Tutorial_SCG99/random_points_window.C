// examples/Tutorial_SCG99/random_points_window.C
// ----------------------------------------------
#include <CGAL/Cartesian.h>
#include <CGAL/Point_2.h>
#include <CGAL/Random.h>
#include <CGAL/point_generators_2.h>
#include <CGAL/copy_n.h>
#include <CGAL/IO/leda_window.h>
#include <CGAL/IO/Ostream_iterator.h>
#include <iterator>
#include <iostream>

typedef CGAL::Cartesian<double>                    Rep;
typedef CGAL::Point_2<Rep>                         Point;
typedef CGAL::Random_points_in_disc_2<Point>       Random_points_in_disc;
typedef CGAL::Ostream_iterator<Point, leda_window> Window_iterator;

int main () {
    CGAL::Random            rnd(1);
    Random_points_in_disc   rnd_pts( 1.0, rnd);

    leda_window* window = CGAL::create_and_display_demo_window();
    CGAL::copy_n( rnd_pts, 100, Window_iterator( *window));
    Point  p;
    *window >> p;     // wait for mouse click
    delete window;
    return 0;
}
