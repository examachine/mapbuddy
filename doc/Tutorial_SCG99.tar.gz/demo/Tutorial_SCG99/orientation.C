// examples/Tutorial_SCG99/orientation.C
// -------------------------------------
#include "tutorial.h"
#include <CGAL/Point_2.h>
#include <CGAL/predicates_on_points_2.h>
#include <iostream>

int main() {
    Point p( 1.0, 0.0);
    Point q( 1.3, 1.7);
    Point r( 2.2, 6.8);
    switch ( CGAL::orientation( p, q, r)) {
	case CGAL::LEFTTURN:   std::cout << "Left turn.\n";  break;
	case CGAL::RIGHTTURN:  std::cout << "Right turn.\n"; break;
	case CGAL::COLLINEAR:  std::cout << "Collinear.\n";  break;
    }
    return 0;
}
