// examples/Tutorial_SCG99/homogeneous_leda_integer.C
// --------------------------------------------------
#include <CGAL/Homogeneous.h>
#include <CGAL/leda_integer.h>
#include <CGAL/Point_2.h>

typedef CGAL::Homogeneous<leda_integer> Rep;
typedef CGAL::Point_2<Rep>              Point;

int main() {
    Point  p( 1, 2, 10);
    return 0;
}
