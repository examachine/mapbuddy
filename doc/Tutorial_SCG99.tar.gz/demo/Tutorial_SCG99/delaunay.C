// examples/Tutorial_SCG99/delaunay.C
// ----------------------------------
#include "tutorial.h"
#include <CGAL/Random.h>
#include <CGAL/point_generators_2.h>
#include <CGAL/copy_n.h>
#include <CGAL/IO/leda_window.h>

int main () {
    CGAL::Random                          rnd(1);  // random points
    CGAL::Random_points_in_disc_2<Point>  rnd_pts( 1.0, rnd);

    Delaunay_triangulation  dt;                    // triangulation
    CGAL::copy_n( rnd_pts, 100, std::back_inserter( dt));

    leda_window* window = CGAL::create_and_display_demo_window();
    *window << dt;                                 // window output
    Point  p;
    *window >> p;
    delete window;
    return 0;
}
