// examples/Tutorial_SCG99/terrain.C
// ---------------------------------
#include "tutorial.h"
#include <CGAL/Point_3.h>
#include <CGAL/Triangulation_euclidean_traits_xy_3.h>
#include <CGAL/IO/Polyhedron_geomview_ostream.h>
#include <algorithm>
#include <iostream>

using namespace std;

typedef CGAL::Point_3<TutorialR>                                   Pt;
typedef CGAL::Triangulation_euclidean_traits_xy_3<TutorialR>       Traits;
typedef CGAL::Triangulation_vertex_base_2<Traits>                  Vb;
typedef CGAL::Triangulation_face_base_2<Traits>                    Fb;
typedef CGAL::Triangulation_default_data_structure_2<Traits,Vb,Fb> Tds;
typedef CGAL::Delaunay_triangulation_2<Traits,Tds>                 Delaunay;

int main () {
    Delaunay  d;
    copy( istream_iterator<Pt>(cin), istream_iterator<Pt>(), back_inserter(d));
    
    CGAL::Geomview_stream geomview( CGAL::Bbox_3( -1,-1,-1, 1,1,1));
    for ( Delaunay::Edge_iterator e = d.edges_begin(); e != d.edges_end(); ++e)
	geomview << d.segment(e);

    Pt click;  // wait for a mouse click.
    geomview >> click;
    return 0;
}
