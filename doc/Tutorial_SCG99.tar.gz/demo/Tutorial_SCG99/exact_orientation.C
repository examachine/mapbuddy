// examples/Tutorial_SCG99/exact_orientation.C
// -------------------------------------------
#include <CGAL/Homogeneous.h>
#include <CGAL/Point_2.h>
#include <CGAL/predicates_on_points_2.h>
#include <iostream>

typedef CGAL::Homogeneous<long>         Rep;
typedef CGAL::Point_2<Rep>              Point;

int main() {
    Point p( 10,  0, 10);
    Point q( 13, 17, 10);
    Point r( 22, 68, 10);
    switch ( CGAL::orientation( p, q, r)) {
	case CGAL::LEFTTURN:   std::cout << "Left turn.\n";  break;
	case CGAL::RIGHTTURN:  std::cout << "Right turn.\n"; break;
	case CGAL::COLLINEAR:  std::cout << "Collinear.\n";  break;
    }
    return 0;
}
