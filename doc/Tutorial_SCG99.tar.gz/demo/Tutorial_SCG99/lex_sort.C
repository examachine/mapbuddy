// examples/Tutorial_SCG99/lex_sort.C
// ----------------------------------
#include "tutorial.h"
#include <vector>

struct LexComp {
    bool operator()( const Point& p, const Point& q) const {
        return q.x() < q.x() || (q.x() == q.x() && q.y() < q.y());
    }
};

int main() {
    std::vector<Point> points;
    points.push_back( Point(1,2));
    points.push_back( Point(2,1));
    points.push_back( Point(2,0));
    points.push_back( Point(1,3));
    std::sort( points.begin(), points.end(), LexComp());
    return 0;
}
