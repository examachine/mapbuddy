// examples/Tutorial_SCG99/cartesian_leda_real.C
// ---------------------------------------------
#include <CGAL/Cartesian.h>
#include <CGAL/leda_real.h>
#include <CGAL/Point_2.h>

typedef CGAL::Cartesian<leda_real>      Rep;
typedef CGAL::Point_2<Rep>              Point;

int main() {
    Point  p( 0.1, 0.2);
    return 0;
}
