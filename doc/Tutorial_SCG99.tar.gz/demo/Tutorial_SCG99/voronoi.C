// examples/Tutorial_SCG99/voronoi.C
// ---------------------------------
#include "tutorial.h"
#include <CGAL/Random.h>
#include <CGAL/point_generators_2.h>
#include <CGAL/copy_n.h>
#include <CGAL/IO/leda_window.h>

int main () {
    CGAL::Random                            rnd(1);  // random points
    CGAL::Random_points_on_circle_2<Point>  rnd_pts( 0.9, rnd);

    Delaunay_triangulation  dt;                    // triangulation
    CGAL::copy_n( rnd_pts, 32, std::back_inserter( dt));
    dt.push_back( Point( 0.0, 0.0));

    leda_window* window = CGAL::create_and_display_demo_window();
    *window << CGAL::GREEN << dt << CGAL::BLACK;   // window output

    Delaunay_triangulation::Face_iterator f = dt.faces_begin();
    while ( f != dt.faces_end()) {
	*window << dt.dual(f);
	++f;
    }
    Delaunay_triangulation::Edge_iterator e = dt.edges_begin();
    while ( e != dt.edges_end()) {
	CGAL::Object o = dt.dual(e);
	Delaunay_triangulation::Segment seg;
	Delaunay_triangulation::Ray     ray;
	if (CGAL::assign( seg, o))
	    *window << CGAL::RED << seg;
	else if (CGAL::assign( ray, o))
	    *window << CGAL::VIOLET << ray;
	++e;
    }
    Point  p;
    *window >> p;
    delete window;
    return 0;
}
