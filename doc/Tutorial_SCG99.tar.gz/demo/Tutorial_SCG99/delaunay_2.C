// examples/Tutorial_SCG99/delaunay_2.C
// ------------------------------------
#include "tutorial.h"
#include <CGAL/Random.h>
#include <CGAL/point_generators_2.h>
#include <CGAL/copy_n.h>
#include <CGAL/IO/leda_window.h>

int main () {
    CGAL::Random                          rnd(1);  // random points
    CGAL::Random_points_in_disc_2<Point>  rnd_pts( 1.0, rnd);

    Delaunay_triangulation  dt;                    // triangulation
    CGAL::copy_n( rnd_pts, 100, std::back_inserter( dt));

    leda_window* window = CGAL::create_and_display_demo_window();
    *window << dt << CGAL::BLUE << Segment( Point(-1,-1), Point(1,1)) 
	    << CGAL::GREEN;

    Delaunay_triangulation::Line_face_circulator lfc = 
	dt.line_walk( Point( 0, 0), Point( 1, 1));
    Delaunay_triangulation::Line_face_circulator lfc_start = lfc;
    do {
	if ( ! dt.is_infinite( lfc))
	    *window << dt.triangle( lfc);
    } while ( ++lfc != lfc_start);

    *window << CGAL::RED;
    Delaunay_triangulation::Vertex_circulator vc = 
	dt.incident_vertices( dt.infinite_vertex());
    Delaunay_triangulation::Vertex_circulator vc_start = vc;
    do {
	*window << vc->point();
    } while ( ++vc != vc_start);

    Point  p;
    *window >> p;
    delete window;
    return 0;
}
