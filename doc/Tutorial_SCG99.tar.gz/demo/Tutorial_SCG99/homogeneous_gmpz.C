// examples/Tutorial_SCG99/homogeneous_gmpz.C
// ------------------------------------------
#include <CGAL/Homogeneous.h>
#include <CGAL/Gmpz.h>
#include <CGAL/Point_2.h>

typedef CGAL::Homogeneous<CGAL::Gmpz>   Rep;
typedef CGAL::Point_2<Rep>              Point;

int main() {
    Point  p( 1, 2, 10);
    return 0;
}
