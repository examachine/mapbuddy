// examples/Tutorial_SCG99/convex_hull_leda.C
// ------------------------------------------
#include <CGAL/Random.h>
#include <CGAL/point_generators_2.h>
#include <CGAL/copy_n.h>
#include <CGAL/convex_hull_2.h>
#include <CGAL/IO/leda_window.h>
#include <CGAL/IO/Ostream_iterator.h>
#include <LEDA/rat_point.h>
#include <list>
#include <algorithm>

typedef leda_rat_point                             Point;
typedef CGAL::Ostream_iterator<Point, leda_window> Window_iterator;

struct Traits {
    typedef  Point       Point_2;    
    struct   Less_xy {
	bool operator()( const Point& p, const Point& q) {
	    return (p.xcoord() <  q.xcoord()) || (
		   (p.xcoord() == q.xcoord()) && (p.ycoord() < q.ycoord()));
	}
    };
    struct   Leftturn {
	bool operator()( const Point& p, const Point& q, const Point& r) {
	    return left_turn( p, q, r); // leda_left_turn
	}
    };
    Less_xy  get_less_xy_object()  const { return Less_xy();  }
    Leftturn get_leftturn_object() const { return Leftturn(); }
};

void operator<<( leda_window& w, const leda_rat_point& p) {
    w.draw_filled_node( p.to_point());
}
template <>
class CGAL::Creator_uniform_2<double,leda_rat_point> {
public:
    leda_rat_point operator()(double a1, double a2) const { 
	return leda_rat_point( leda_rational(a1), leda_rational(a2));
    }
};

int main () {
    CGAL::Random                          rnd(1);  // random points
    CGAL::Random_points_in_disc_2<Point>  rnd_pts( 1.0, rnd);
    std::list<Point>                      pts;
    CGAL::copy_n( rnd_pts, 100, std::back_inserter( pts));

    std::list<Point>  ch;                                   // convex hull
    CGAL::ch_graham_andrew( pts.begin(), pts.end(), 
			    std::back_inserter( ch), Traits());

    leda_window* window = CGAL::create_and_display_demo_window();
    Window_iterator wout( *window);                // window output
    std::copy( pts.begin(), pts.end(), wout);
    *window << CGAL::GREEN;
    std::list<Point>::iterator i = ch.begin(), j = i;
    for ( ; ++j != ch.end(); ++i)
	window->draw_segment( i->to_point(), j->to_point());
    window->draw_segment( ch.begin()->to_point(), (--j)->to_point());
    *window << CGAL::RED;
    std::copy( ch.begin(), ch.end(), wout);
    window->read_mouse();
    delete window;
    return 0;
}
