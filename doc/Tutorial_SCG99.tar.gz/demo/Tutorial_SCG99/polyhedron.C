// examples/Tutorial_SCG99/polyhedron.C
// ------------------------------------
#include <CGAL/Cartesian.h>
#include <CGAL/Point_3.h>
#include <CGAL/Vector_3.h>
#include <CGAL/Aff_transformation_3.h>
#include <CGAL/Halfedge_data_structure_polyhedron_default_3.h>
#include <CGAL/Polyhedron_default_traits_3.h>
#include <CGAL/Polyhedron_3.h>
#include <CGAL/IO/Polyhedron_iostream.h>

typedef CGAL::Cartesian<double>                          Rep;
typedef CGAL::Vector_3<Rep>                              Vector;
typedef CGAL::Aff_transformation_3<Rep>                  Affine;
typedef CGAL::Polyhedron_default_traits_3<Rep>           Traits;
typedef CGAL::Halfedge_data_structure_polyhedron_default_3<Rep> HDS;
typedef CGAL::Polyhedron_3<Traits,HDS>                   Polyhedron;

// The declaration of a point iterator for a Polyhedron
#include <CGAL/Iterator_project.h>
#include <CGAL/function_objects.h>

typedef Polyhedron::Vertex_iterator                      Vertex_iterator;
typedef Polyhedron::Vertex                               Vertex;
typedef CGAL::Project_point<Vertex>                      Project;
typedef CGAL::Point_3<Rep>                               Point;
typedef CGAL::Iterator_project<Vertex_iterator, Project,
             Point&, Point*>                             Point_iterator;

struct Triangulate {
    Polyhedron* P;
    Triangulate( Polyhedron& pol) : P(&pol) {}
    typedef Polyhedron::Facet Facet;
    void operator()( Facet& f) {
	while ( CGAL::circulator_size( f.facet_begin ()) > 3)
	    P->split_facet( f.halfedge(), f.halfedge()->next()->next());
    }
};

int main () {
    Polyhedron P;
    std::cin >> P;
    Affine A = Affine( CGAL::SCALING, 0.5) * 
	       Affine( CGAL::TRANSLATION, Vector( 0.5, 0.0, 0.0));
    Point_iterator pbegin = P.vertices_begin();
    Point_iterator pend   = P.vertices_end();
    std::transform( pbegin, pend, pbegin, A);
    std::for_each( P.facets_begin(), P.facets_end(), Triangulate(P));
    std::cout << P;
    return 0;
}
