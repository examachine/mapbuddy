// examples/Tutorial_SCG99/convex_hull.C
// -------------------------------------
#include "tutorial.h"
#include <CGAL/Random.h>
#include <CGAL/point_generators_2.h>
#include <CGAL/copy_n.h>
#include <CGAL/convex_hull_2.h>
#include <CGAL/IO/leda_window.h>
#include <CGAL/IO/Ostream_iterator.h>
#include <list>
#include <algorithm>

typedef CGAL::Ostream_iterator<Point, leda_window> Window_iterator;

int main () {
    CGAL::Random                          rnd(1);  // random points
    CGAL::Random_points_in_disc_2<Point>  rnd_pts( 1.0, rnd);
    std::list<Point>                      pts;
    CGAL::copy_n( rnd_pts, 100, std::back_inserter( pts));

    Polygon  ch;                                   // convex hull
    CGAL::convex_hull_points_2( pts.begin(), pts.end(), 
				std::back_inserter( ch));

    leda_window* window = CGAL::create_and_display_demo_window();
    Window_iterator wout( *window);                // window output
    std::copy( pts.begin(), pts.end(), wout);
    *window << CGAL::GREEN << ch << CGAL::RED;
    std::copy( ch.vertices_begin(), ch.vertices_end(), wout);
    Point  p;
    *window >> p;
    delete window;
    return 0;
}
