// examples/Tutorial_SCG99/random_points.C
// ---------------------------------------
#include <CGAL/Cartesian.h>
#include <CGAL/Point_2.h>
#include <CGAL/Random.h>
#include <CGAL/point_generators_2.h>
#include <CGAL/copy_n.h>
#include <iterator>
#include <iostream>

typedef CGAL::Cartesian<double>              Rep;
typedef CGAL::Point_2<Rep>                   Point;
typedef CGAL::Random_points_in_disc_2<Point> Random_points_in_disc;

int main () {
    CGAL::Random            rnd(1);
    Random_points_in_disc   rnd_pts( 1.0, rnd);
    CGAL::copy_n( rnd_pts, 8, 
		  std::ostream_iterator<Point>(std::cout, "\n"));
    return 0;
}
