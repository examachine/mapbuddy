// examples/Tutorial_SCG99/points_and_vectors.C
// --------------------------------------------
#include "tutorial.h"
#include <CGAL/Point_2.h>
#include <CGAL/Vector_2.h>
#include <iostream>

int main() {
    Point  p1(  1.0, -1.0);
    Point  p2(  4.0,  3.0);
    Vector v1( -1.0, 10.0);
    Vector v2( p2 - p1);
    v1 = v1 + v2;
    Point p3 = p2 + v1 * 2.0;
    std::cout << "v2 = (" << v2.x() << ", " << v2.y() << ")\n";
    std::cout << "p3 = (" << p3.x() << ", " << p3.y() << ")\n";
    return 0;
}
